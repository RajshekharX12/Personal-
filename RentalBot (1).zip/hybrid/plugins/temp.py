#(©) @Hybrid_Vamp - https://github.com/hybridvamp

class temp(object):
    BOT_UN = None
    TEMP_VAR1 = []
    TEMP_VAR2 = []
    PAID_LOCK = []
    INV_DICT = {}
    PENDING_INV = []
    NUMBE_RS = []
    AVAILABLE_NUM = []
    RENTED_NUMS = []
    UN_AV_NUMS = []
    BLOCKED_NUMS = []
    RESTRICTED_NUMS = []
    