git config --global user.email "youremail@gmail.com" && git config --global user.name "githubusername"
python3 -m hybrid